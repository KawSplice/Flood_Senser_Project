/*
 * Final_Project_Flood_Sensor.c
 * Created: 6/3/2021 3:38:06 PM
 * Author : luis.solis
 */ 

// Defines
#define FALSE 0
#define TRUE !FALSE

// Include Files
#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "uartDriver.h"
uint8_t ReadADC(uint8_t ADCchannel);
#define WireCom (1 << DDB4)
#define DATA_MASK 0b10000000

//Function Prototypes
void sendData(void);

//Globals/Constants
static volatile uint8_t data = 0;

int main(void)
{
	// Create File Pointers for in and out
	FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
	FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);

	// Initialize the UART Driver
	uart_init();

	// Hijack STDIN/STDOUT and send then to the UART Driver
	stdout = &uart_output;
	stdin  = &uart_input;
	
	// output for Adc
	DDRB |= WireCom;
	PORTB &= ~WireCom;
	
	// Select Vref=AVcc
	ADMUX |= (1<<REFS0)|(1<<ADLAR);

	//set prescaller to 128 and enable ADC
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)|(1<<ADEN);
	uint8_t adcValue = 0; 
	
	//Send Welcome message to UART
	printf("Simple Communications Example - Server\n");

	
	while (TRUE)
	{	 
			// reading 
			adcValue = ReadADC(1);
			//Set the Data Value to send
			data = adcValue;
	
			//Print this value to the UART
			printf("Sending data: %u\n", data);

			//Send the Data to the Client
			sendData();

			//Delay before sending the next value
			_delay_ms(1000);

	}
	
	return 0;
}

uint8_t ReadADC(uint8_t ADCchannel)
{
	//select ADC channel with safety mask
	ADMUX = (ADMUX & 0xF0) | (ADCchannel & 0x0F)|(1<<ADLAR);

	//single conversion mode
	ADCSRA |= (1<<ADSC);
	
	// wait until ADC conversion is complete
	while( ADCSRA & (1<<ADSC) );
	
	return ADCH;
}
/**********************************************************************
* Purpose: This ISR Handle the Overflow Vector of Timer 0
*
* Precondition:
*     Interrupt must be enabled
*
* Postcondition:
*      Timer 0 Overflow event handled
*
************************************************************************/
ISR(TIMER0_OVF_vect)
{
	//variable to keep track of number of overflows
	static uint8_t numOverflows = 0;

	//Count number of overflows that have occurred
	numOverflows++;

	if(numOverflows > 10)			//Once we have reached 10 overflows
	{
		sendData();					//Call the sendData Function to send next bit
		numOverflows = 0;			//Reset the Number of Overflows
	}
}

/**********************************************************************
* Purpose: This function sends bits to the client board
*
* Precondition:
*     Data set in the global variable and a timer to time the bits
*
* Postcondition:
*      Data sent to client
*
************************************************************************/
void sendData(void)
{
	//variable to keep track of current Bit Position
	static uint8_t BitCount = 0;

	//Send Current Bit Position and value to UART
	//printf("SendData: BitCount = %u, Data Value: %u\n", BitCount, data);

	if (BitCount == 0)								//Are we the first bit?
	{
		PORTB |= WireCom;							//Set The Bit High to indicate Start of Frame
		BitCount++;									//increment Bit Count
		TCCR0B |= ((1 << CS02) | (1 << CS00));		//Set Timer Prescaler to Start it
		TIMSK0 |= (1 << TOIE0);						//Enable Overflow Interrupt
		TCNT0 = 0;									//Clear Timer
		sei();										//Enable Global Interrupts
	}
	else if(BitCount <= 8)							//Are we sending Data Bits?
	{
		if(data & DATA_MASK)						//Are we sending a 1?
		{
			//printf("Sending a 1\n");				//Send to UART
			PORTB |= WireCom;						//Set BIT
		}
		else										//Otherwise sending a 0
		{
			//printf("Sending a 0\n");				//Send to UART
			PORTB &= ~WireCom;					//Clear BIT
		}
		data <<= 1;									//Shift Data to set up for next BIT
		BitCount++;									//Increment count
	}
	else											//Otherwise we are done sending data
	{
		//printf("Transmission Complete. Disabling Timer.\n");	//Send to UART
		TCCR0B = 0;									//Turn off timers clock source
		TIMSK0 = 0;									//turn off timer interrupt
		TCNT0 = 0;									//Clear Timer
		PORTB &= ~WireCom;						//Ensure PIN is low
		BitCount = 0;								//reset bit count
		cli();										//Disable global interrupts
	}
}
